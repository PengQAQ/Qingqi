﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Add : MonoBehaviour {

	public GameObject p;
	// Use this for initialization
	void Start () {
		Instantiate(p);
		p.transform.SetParent(this.gameObject.transform);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
