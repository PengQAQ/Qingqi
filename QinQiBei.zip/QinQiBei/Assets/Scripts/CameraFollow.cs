﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    //[HideInInspector] public int flag;
    public int flag;
    private float smoothingSpeed = 8f;
    private Transform nextPos;

    private void Start()
    {
        if (Global.Player.transform.childCount > 0)
        {
            flag = 0;
            ChangeFigure();
        }
        else
            return;
    }

    private void FixedUpdate ()
    {
        CameraF();
         //nextPos = Global.Player.transform.GetChild(flag).gameObject.transform;
         //transform.position = Vector3.Lerp(transform.position, new Vector3(nextPos.position.x, nextPos.position.y, -10), smoothingSpeed * Time.deltaTime);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            if (flag == Global.Player.transform.childCount - 1)
                flag = 0;
            else
                flag++;
            ChangeFigure();
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            if (flag == 0)
                flag = Global.Player.transform.childCount - 1;
            else
                flag--;
            ChangeFigure();
        }
        if (flag < 0)
            flag = 0;
    }

    private void ChangeFigure()
    {
        Global.CtrlTool.transform.position = new Vector3(Global.Player.transform.GetChild(flag).transform.position.x, Global.Player.transform.GetChild(flag).transform.position.y, Global.Player.transform.GetChild(flag).transform.position.z);
        Global.CtrlTool.transform.parent = Global.Player.transform.GetChild(flag);
    }

    public void CameraF()
    {
        if(Global.Player.transform.childCount>0)
        {
            nextPos = Global.Player.transform.GetChild(flag).gameObject.transform;
            transform.position = Vector3.Lerp(transform.position, new Vector3(nextPos.position.x, nextPos.position.y, -10), smoothingSpeed * Time.deltaTime);

        }
    }
}