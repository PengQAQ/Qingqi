﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Global
{

    public static GameObject MainCamera;
    //public static GameObject UIRoot;
    public static GameObject GameManager;
    public static GameObject Player;
    public static GameObject Enemy;
    public static GameObject CtrlTool;
}
