﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PropChangeSP : MonoBehaviour {

    [SerializeField] private float changes = 0f;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        collision.gameObject.GetComponent<FigureMove>().ChangeSP(changes);
        Destroy(this.gameObject);
    }
}
