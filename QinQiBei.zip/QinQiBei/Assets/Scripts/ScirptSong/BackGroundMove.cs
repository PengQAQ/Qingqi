﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackGroundMove : MonoBehaviour {

	public Transform[] backgrounds;
	public float compensation;      //移动补偿值
	public float differCompensation;//每层移动差值
	private Vector3 preCameraPos;   //相机上一帧的位置
	private Transform cam;
	private float differ;
	public float smoothing;
	void Start()
    {
		cam = Camera.main.transform;
		preCameraPos = cam.position;
		//differ = (preCameraPos.x - cam.position.x) * compensation;
	}
	
	void Update()
    {
		differ = (preCameraPos.x - cam.position.x) * compensation;
		for(int i=0;i< backgrounds.Length;i++)
        {
			//backgrounds[i].position = new Vector3(cam.position.x, backgrounds[i].position.y, i - 1);
			float backgroundPoxY = backgrounds[i].position.x + differ * (i * differCompensation + 1);
			Vector3 backgroundTargetPos = new Vector3(backgroundPoxY, backgrounds[i].position.y, backgrounds[i].position.z);
			//backgrounds[i].position = new Vector3(cam.position.x, backgrounds[i].position.y, 0);
			backgrounds[i].position = Vector3.Lerp(backgrounds[i].position, backgroundTargetPos, smoothing * Time.deltaTime);
		}
		preCameraPos = cam.position;
	}

}
