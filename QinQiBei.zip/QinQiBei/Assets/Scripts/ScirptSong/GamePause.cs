﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GamePause : MonoBehaviour {

    private int TimeGoFlag;
    private Sprite pause;
    private Sprite resume;
    void Start()
    {
        TimeGoFlag = 1;
        pause = Resources.Load("Image/btnPlay", typeof(Sprite)) as Sprite;
        resume = Resources.Load("Image/btnPause", typeof(Sprite)) as Sprite;
    }
	public void PauseAndResume()
    {
        if(TimeGoFlag == 1)
        {
            Time.timeScale = 0;
            TimeGoFlag = 0;
            this.GetComponent<Image>().sprite = pause;
        }
            
        else
        {
            Time.timeScale = 1;
            TimeGoFlag = 1;
            this.GetComponent<Image>().sprite = resume;
        }
            
    }

    
}
