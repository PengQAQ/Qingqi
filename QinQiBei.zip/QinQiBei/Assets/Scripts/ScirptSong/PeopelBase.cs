﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PeopelBase : MonoBehaviour {

    public string imagePath;
    void Start()
    {
        imagePath = "Image/奔跑1";
    }
    /*void OnCollisionEnter(Collider2D collision)
    {
         for(int i=0;i<GamePanel.imgArray.Length;i++)
         {
             if(GamePanel.imgArray[i].GetComponent<MyDrop>().imgName != "null")
             {
                GamePanel.imgArray[i].GetComponent<MyDrop>().imgName = collision.name;
                GamePanel.imgArray[i].sprite = (Sprite)Resources.Load(imagePath);
                break;
             }
         }
    }*/
}
