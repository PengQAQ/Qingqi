﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Restart:MonoBehaviour {
    public static int restartFlag = 0;
    public void ToRestart()
    {
        restartFlag = 1;
        SceneManager.LoadScene("Game1");
        
        //GameObject.Find("GameManager").gameObject.GetComponent<GameManager>().Init();
        //UIManager.Instance.PushPanel("Game");
    }
    public static void ChangeFlag()
    {
        restartFlag = 0;
    }
}
