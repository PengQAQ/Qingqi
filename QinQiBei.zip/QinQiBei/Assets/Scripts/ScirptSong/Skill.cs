﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skill:MonoBehaviour
{
    public void Fast(string ob)
	{
		GameObject obj = GameObject.Find(ob).gameObject;
		float accelerateMultiple = 2f;
		float duringTime = 2f;
		obj.gameObject.GetComponent<FigureMove>().GetMultiple(accelerateMultiple, duringTime);
	}
	public void SkillNeiShiTeng(string ob)
	{
        GameObject.Find("NeiShiTeng").GetComponent<SkillNeiShiTeng>().enabled = true;
	}

	public void Test3(string ob)
	{
		GameObject obj = GameObject.Find(ob).gameObject;
		Debug.Log("Test3");
	}

	public void Test4(string ob)
	{
		GameObject obj = GameObject.Find(ob).gameObject;
		Debug.Log("Test3");
	}


}
