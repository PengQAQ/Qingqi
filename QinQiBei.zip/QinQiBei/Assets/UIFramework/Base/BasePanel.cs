﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//所有界面面板的基类
public  class BasePanel : MonoBehaviour {

    /// <summary>
    /// 界面显示
    /// </summary>
	public virtual void OnEnter()
    {
        CanvasGroup canvasGroup = GetComponent<CanvasGroup>();
        canvasGroup.alpha = 1;
        canvasGroup.blocksRaycasts = true;
    }

    /// <summary>
    /// 界面暂停
    /// </summary>
    public virtual void OnPause()
    {

    }

    /// <summary>
    /// 界面退出
    /// </summary>
    public virtual void OnExit()
    {
        //if(this!=null)
        //{
            CanvasGroup canvasGroup = GetComponent<CanvasGroup>();
            canvasGroup.alpha = 0;
            canvasGroup.blocksRaycasts = false;
        //}
        
    }


    /// <summary>
    /// 界面继续
    /// </summary>
    public virtual void OnResume()
    {

    }
    
}
