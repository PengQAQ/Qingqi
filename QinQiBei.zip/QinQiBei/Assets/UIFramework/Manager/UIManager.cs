﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using LitJson;
using System.IO;

public class UIManager{
    //外部使用
	public static UIManager _instance;
	public static UIManager Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new UIManager();
            }
            else if(Restart.restartFlag == 1)
            {
                _instance = new UIManager();
                Restart.ChangeFlag();
            }
            return _instance;
        }
	}

    private UIManager()
    {
        ParseUITypeToJson();
    }

    private Dictionary<string, string> panelPathDict;
    private Dictionary<string, BasePanel> panelDict;
    private Stack<BasePanel> panelStack;

    /// <summary>
    /// 获取Canvas
    /// </summary>
    private Transform canvasTransform;
    private Transform CanvasTransform
    {
        get
        {
            if (canvasTransform == null)
                canvasTransform = GameObject.Find("Canvas").transform;
            return canvasTransform;
        }
    }

    /// <summary>
    /// 解析json，将面板信息加入到字典中
    /// </summary>
    private void ParseUITypeToJson()
    {
        panelPathDict = new Dictionary<string, string>();
        string path = Application.dataPath + "/Resources/UI.json";
        StreamReader json = File.OpenText(path);
        string input = json.ReadToEnd();
        JsonData js = JsonMapper.ToObject(input);
        foreach (JsonData j in js)
        {
            panelPathDict.Add(j[0].ToString(), j[1].ToString());
        }
    }

    public BasePanel GetPanel(string panleType)
    {
        if (panelDict == null)
            panelDict = new Dictionary<string, BasePanel>();
        BasePanel panel;
        panelDict.TryGetValue(panleType, out panel);
        
        //没有找到面板，需要从资源中实例化并加入到字典
        if (panel == null)
        {
            string path;
            panelPathDict.TryGetValue(panleType, out path);
            //string path = panelPathDict.TryGet(panleType);
            GameObject instPanel = GameObject.Instantiate(Resources.Load(path)) as GameObject;//强转

            //后面的参数true，false表示是否保持在世界坐标的位置
            instPanel.transform.SetParent(CanvasTransform, false);

            //将实例化的面板加入到面板字典中，方便下次使用
            panelDict.Add(panleType, instPanel.GetComponent<BasePanel>());
            return instPanel.GetComponent<BasePanel>();
        }
        else//找到则返回这个面板
        {
            return panel;
        }
    }
    /// <summary>
    /// 将页面入栈，然后显示
    /// </summary>
    public void PushPanel(string panelType)
    {
        //栈为空时，创建栈
        if (panelStack == null)
            panelStack = new Stack<BasePanel>();

        //判断栈中是否有页面
        if (panelStack.Count > 0)
        {
            BasePanel topPanel = panelStack.Peek();
            topPanel.OnExit();
        }
        BasePanel panel = GetPanel(panelType);
        panel.OnEnter();
        panelStack.Push(panel);
    }

    /// <summary>
    /// 将页面出栈，然后移除
    /// </summary>
    public void PopPanel()
    {
        //栈为空时，创建栈
        if (panelStack == null)
            panelStack = new Stack<BasePanel>();

        if (panelStack.Count <= 0)
            return;

        //关闭栈顶页面的显示
        BasePanel topPanel = panelStack.Pop();
        topPanel.OnExit();

        if (panelStack.Count <= 0)
            return;
        //下一个界面继续
        BasePanel topPanel2 = panelStack.Pop();
        topPanel2.OnEnter();
    }
}
