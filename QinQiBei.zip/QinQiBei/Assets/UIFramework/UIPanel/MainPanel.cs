﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainPanel : BasePanel {
    
    public void ChangePanel(string panelName)
    {
        UIManager.Instance.PushPanel(panelName);
        
    }
}
