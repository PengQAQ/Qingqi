﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BkFollow : MonoBehaviour
{
    void Update ()
    {
        transform.position = new Vector3(Global.MainCamera.transform.position.x, Global.MainCamera.transform.position.y, 0);
	}
}
