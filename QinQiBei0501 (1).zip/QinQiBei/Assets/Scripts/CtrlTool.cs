﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CtrlTool : MonoBehaviour
{
    private Collider2D myBottomC2D;
    private bool onFloor = false;
    private float force = 5f;
	
	void Update ()
    {
        onFloor = CheckOnFloor();
        if (Input.GetKeyDown(KeyCode.Space) && onFloor)
        {
            Global.CtrlTool.transform.parent.GetComponent<Rigidbody2D>().velocity += new Vector2(0, 1) * force;
        }
    }

    private bool CheckOnFloor()
    {
        myBottomC2D = this.transform.parent.GetComponent<Collider2D>();
        return myBottomC2D.IsTouchingLayers(LayerMask.GetMask("Floor"));
    }
}
