﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExitTrigger : MonoBehaviour {

    public static int ArriveCount = 0;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.transform.parent.name == "Enemy" || collision.transform.parent.name == "Player")
        {
            collision.GetComponent<FigureMove>().enabled = false;
            collision.GetComponent<Animator>().enabled = false;
        }
        if (collision.transform.parent.name == "Player" && ArriveCount < 3)
        {
            collision.transform.SetParent(GameObject.Find("GameManager").gameObject.transform);
            ArriveCount++;
        }

        if(ArriveCount == 3)
        {
            GameObject ob = GameObject.Find("Pause").gameObject;
            ob.GetComponent<GamePause>().PauseAndResume();
            UIManager.Instance.GetPanel("Over");

        }
    }


}
