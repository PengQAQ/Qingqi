﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FigureMove : MonoBehaviour
{
    private float accelerateMultiple = 1f;  //加速冲刺、减速萎靡的倍数
    private Vector3 nextPos;  //运动的下一位置

    private float v;  //速度
    [SerializeField] float v_min;  //最小速度
    private float a;  //加速度
    [SerializeField] float a_max;  //最大加速度
    private float sp;  //体力
    [SerializeField] float sp_max;  //最大体力
    [SerializeField] float sp_a; //体力衰竭率

    private void Start()
    {
        v = v_min;
        sp = sp_max;
    }

    private void FixedUpdate()
    {
        GetSpeed();
        nextPos = new Vector3(gameObject.transform.position.x + v * Time.deltaTime * accelerateMultiple, gameObject.transform.position.y, gameObject.transform.position.z);
        this.gameObject.transform.position = nextPos;
    }

    private void GetSpeed()
    {
        sp -= (sp_a * 0.02f);
        if (sp > 0)
        {
            a = a_max / sp_max * sp;
            v = v + (a * 0.02f);
        }
        else
        {
            sp = 0;
            v = v - (a_max * 0.02f);
            if (v <= v_min)
            {
                v = v_min;
            }
        }
    }

    public void GetMultiple(float accelerateMultiple, float duringTime)  //改变冲刺倍数或者萎靡倍数以及持续时间
    {
        this.accelerateMultiple = accelerateMultiple;
        Invoke("ReturnMultiple", duringTime);
    }

    private void ReturnMultiple()
    {
        this.accelerateMultiple = 1f;
    }

    public void ChangeSP(float change)  //改变体力
    {
        sp += change;
        if (sp > sp_max)
            sp = sp_max;
    }
}
