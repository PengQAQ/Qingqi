﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public GameObject Players;
    public GameObject Enemys;
    public GameObject BF;
    public GameObject Ctrl;
    private void Awake()
    {
        Global.MainCamera = GameObject.Find("Main Camera");
        Global.GameManager = GameObject.Find("GameManager");
        //Global.UIRoot = GameObject.Find("UIRoot");
        Global.Player = GameObject.Find("Player");
        Global.Enemy = GameObject.Find("Enemy");
        Global.CtrlTool = GameObject.Find("CtrlTool");

        Players.SetActive(false);
        Enemys.SetActive(false);
        BF.SetActive(false);
        Ctrl.SetActive(false);
    }
}
