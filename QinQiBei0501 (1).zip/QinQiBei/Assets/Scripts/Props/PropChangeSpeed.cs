﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PropChangeSpeed : MonoBehaviour
{
    //[SerializeField] private float accelerateMultiple = 1f;
    //[SerializeField] private float duringTime = 2f;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.name != "Route" && collision.transform.parent.name != "Enemy")
        {
            for (int i = 0; i < GamePanel.imgArray.Length; i++)
            {
                if (GamePanel.imgArray[i].GetComponent<SkillDrop>().imgName == "null")
                {
                    GamePanel.imgArray[i].GetComponent<SkillDrop>().imgName = this.name;
                    GamePanel.imgArray[i].GetComponent<SkillDrop>().ChangeImg(this.name);
                    break;
                 }
            }
                    //collision.gameObject.GetComponent<FigureMove>().GetMultiple(accelerateMultiple, duringTime);
            Destroy(this.gameObject);
        }
        if (collision.transform.parent.name == "Enemy")
        {
            Destroy(this.gameObject);
        }
    }
}
