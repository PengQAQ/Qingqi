﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI : MonoBehaviour {

    public GameObject AiJumpPoint1;
    public GameObject AiJumpPoint2;
    private float force = 3f;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void FixedUpdate () {
        IsJump();

    }

    public void IsJump()
    {
        for(int i=0;i<3;i++)
        {
            if (Mathf.Abs( Global.Enemy.transform.GetChild(i).position.x -AiJumpPoint1.transform.position.x ) <= 0.15f|| Mathf.Abs(Global.Enemy.transform.GetChild(i).position.x - AiJumpPoint2.transform.position.x) <= 0.15f)
            {
               
                Global.Enemy.transform.GetChild(i).GetComponent<Rigidbody2D>().velocity += new Vector2(0, 1) * force;

            }
        }
    }
}
