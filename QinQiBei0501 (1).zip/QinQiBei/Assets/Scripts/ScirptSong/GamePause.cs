﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GamePause : MonoBehaviour {

    private int TimeGoFlag;
    void Start()
    {
        TimeGoFlag = 1;
    }
	public void PauseAndResume()
    {
        if(TimeGoFlag == 1)
        {
            Time.timeScale = 0;
            TimeGoFlag = 0;
        }
            
        else
        {
            Time.timeScale = 1;
            TimeGoFlag = 1;
        }
            
    }

}
