﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Person {

	public static GameObject[] objArray;   //人物数组 
	private static int num = 3;				//人物数目
	
	
	/// <summary>
	/// 静态构造方法，只执行一次
	/// </summary>
	static Person()
    {
		//GetObjArray();

	}
	static void  GetObjArray()
    {
		objArray = new GameObject[num];
        //GameObject grandPa = GameObject.Find("AllObject");
		GameObject parent = GameObject.Find("Player");
		int i = 0;
		foreach (Transform child in parent.transform)
		{
			GameObject ob = GameObject.Find(child.name);
			objArray[i] = ob;
			i++;
			Debug.Log(child.name);
		}
	}
}
