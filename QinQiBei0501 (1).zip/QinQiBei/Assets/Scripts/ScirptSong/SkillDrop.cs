﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class SkillDrop : MonoBehaviour
{
    public string imgName;

    public virtual void ChangeImg(string skillName)
    {
        
    }
}
