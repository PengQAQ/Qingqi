﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class SkillOneDrop : SkillDrop, IPointerDownHandler, IDragHandler, IPointerUpHandler,
    IEndDragHandler, IPointerEnterHandler, IPointerExitHandler
{
    public RectTransform canvas;          //得到canvas的ugui坐标
    public RectTransform imgRect;        //得到图片的ugui坐标
    public Vector3 HistoryPos;           //图片原来位置
    //public string imgName;               //用来判断技能名称和是否有技能
    public float MinDistance;           //触发的最小距离
    public Vector2 offset = new Vector3();    //用来得到鼠标和图片的差值
    public Vector3 imgReduceScale = new Vector3(1.2f, 1.2f, 1);   //设置图片缩放
    public Vector3 imgNormalScale = new Vector3(1, 1, 1);   //正常大小

    // Use this for initialization
    void Start()
    {
        canvas = (RectTransform)GameObject.Find("Canvas").transform;
        imgName = "null";
        MinDistance = 50f;
        imgRect = GetComponent<RectTransform>();
        HistoryPos = imgRect.transform.position;
    }

    void FixedUpdate()
    {
        if(GameObject.Find("Player")!=null)
            HighLight();
    }


    //当鼠标按下时调用 接口对应  IPointerDownHandler
    public void OnPointerDown(PointerEventData eventData)
    {
        if (imgName != "null")
        {
            Vector2 mouseDown = eventData.position;    //记录鼠标按下时的屏幕坐标
            Vector2 mouseUguiPos = new Vector2();   //定义一个接收返回的ugui坐标
            //RectTransformUtility.ScreenPointToLocalPointInRectangle()：把屏幕坐标转化成ugui坐标
            //canvas：坐标要转换到哪一个物体上，这里img父类是Canvas，我们就用Canvas
            //eventData.enterEventCamera：这个事件是由哪个摄像机执行的
            //out mouseUguiPos：返回转换后的ugui坐标
            //isRect：方法返回一个bool值，判断鼠标按下的点是否在要转换的物体上
            bool isRect = RectTransformUtility.ScreenPointToLocalPointInRectangle(canvas, mouseDown, eventData.enterEventCamera, out mouseUguiPos);
            if (isRect)   //如果在
            {
                //计算图片中心和鼠标点的差值
                offset = imgRect.anchoredPosition - mouseUguiPos;
            }
        }

    }

    //当鼠标拖动时调用   对应接口 IDragHandler
    public void OnDrag(PointerEventData eventData)
    {
        if (imgName != "null")
        {
            Vector2 mouseDrag = eventData.position;   //当鼠标拖动时的屏幕坐标
            Vector2 uguiPos = new Vector2();   //用来接收转换后的拖动坐标
            //和上面类似
            bool isRect = RectTransformUtility.ScreenPointToLocalPointInRectangle(canvas, mouseDrag, eventData.enterEventCamera, out uguiPos);

            if (isRect)
            {
                //设置图片的ugui坐标与鼠标的ugui坐标保持不变
                imgRect.anchoredPosition = offset + uguiPos;
            }
            GameObject.Find("Skill2").GetComponent<SkillTwoDrop>().enabled = false;
            GameObject.Find("Skill3").GetComponent<SkillThrDrop>().enabled = false;
        }
    }

    //当鼠标抬起时调用  对应接口  IPointerUpHandler
    public void OnPointerUp(PointerEventData eventData)
    {
        offset = Vector2.zero;
    }

    //当鼠标结束拖动时调用   对应接口  IEndDragHandler
    public void OnEndDrag(PointerEventData eventData)
    {
        string str = FindMinDistanceObj();
        if(imgName == "Slow")
        {
            GameObject ob = Resources.Load("Prefab/Slow") as GameObject;
            Vector3 dis = Camera.main.ScreenToWorldPoint(imgRect.position);
            dis = new Vector3(dis.x, dis.y, 0);
            Instantiate(ob, dis, imgRect.rotation);
            ChangeImgToNull();
            imgRect.transform.position = HistoryPos;
            offset = Vector2.zero;
        }
        else if (str == "")
            imgRect.transform.position = HistoryPos;
        else 
        {
            SkillSystem.Instance.Getskill(imgName, str);    //调用技能
            ChangeImgToNull();
            imgRect.transform.position = HistoryPos;
            offset = Vector2.zero;
        }

        GameObject.Find("Skill2").GetComponent<SkillTwoDrop>().enabled = true;
        GameObject.Find("Skill3").GetComponent<SkillThrDrop>().enabled = true;
    }

    //当鼠标进入图片时调用   对应接口   IPointerEnterHandler
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (imgName != "null")
            imgRect.localScale = imgReduceScale;   //放大图片
    }

    //当鼠标退出图片时调用   对应接口   IPointerExitHandler
    public void OnPointerExit(PointerEventData eventData)
    {
        imgRect.localScale = imgNormalScale;   //回复图片
    }


    /// <summary>
    /// 找到最小距离的物体
    /// 如果距离小于最小距离，则返回物体名称
    /// </summary>
    public string FindMinDistanceObj()
    {
        float min = 99999;
        float distance;
        int flag = 0;
        for (int i = 0; i < GamePanel.objArray.Length; i++)
        {
            Vector3 dis = Camera.main.WorldToScreenPoint(GamePanel.objArray[i].transform.position);
            dis = new Vector3(dis.x, dis.y, 0);
            distance = Vector3.Distance(imgRect.position, dis);
            if (distance < min)
            {
                flag = i;
                min = distance;
            }
        }
        if (min <= MinDistance)
            return GamePanel.objArray[flag].name;
        else
            return "";
    }

    /// <summary>
    /// 高光
    /// </summary>
    public void HighLight()
    {
        string str = FindMinDistanceObj();
        if (str != "")
        {
            GameObject ob = GameObject.Find(str).gameObject;
            ob.GetComponent<Renderer>().material.SetInt("_DualGrid", 1);
        }
        else
        {
            foreach (GameObject child in GamePanel.objArray)
            {
                child.GetComponent<Renderer>().material.SetInt("_DualGrid", 0);
            }
        }
    }

    /// <summary>
    /// 更换技能贴图
    /// </summary>
    public override void ChangeImg(string skillName)
    {
        string imagePath = "Skill/" + skillName;

        Sprite sprite = Resources.Load(imagePath, typeof(Sprite)) as Sprite;
        this.GetComponent<Image>().sprite = sprite;

        imgName = skillName;
    }

    /// <summary>
    /// 为拾到技能前，和使用技能后需要将技能图片置空
    /// </summary>
    public void ChangeImgToNull()
    {
        Sprite sprite = null;
        this.GetComponent<Image>().sprite = sprite;
        imgName = "null";
    }

}
