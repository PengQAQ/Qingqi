﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
/// <summary>
/// 技能系统管理
/// 使用单例模式管理
/// </summary>
public class SkillSystem{

    public static SkillSystem _instance;
    public static SkillSystem Instance
    {
        get
        {
            if (_instance == null)
                _instance = new SkillSystem();
            return _instance;
        }
    }

    /// <summary>
    /// 通过反射机制调用Skill中的方法
    /// 传入参数skillName为技能名称（对应Skill类的中的方法名）
    /// 参数obName为需要执行该技能的物体名称
    /// </summary>
    /// <param name="skillName"></param>
    /// <param name="obName"></param>
    public void Getskill(string skillName, string obName)
    {
        string className = "Skill";                             //技能类名
        System.Object[] paras = new System.Object[] { obName }; //将obName作为参数传递
        var t = Type.GetType(className);                        //得到该类型
        object obj = Activator.CreateInstance(t);               //由于object是所有类型的基类，所以创建一个object的实例来接收泛型
        MethodInfo method = t.GetMethod(skillName);             //反射机制
        if (method != null) 
            method.Invoke(obj, paras);                          //方法调用
        else 
            Debug.Log("error");
    }
}
