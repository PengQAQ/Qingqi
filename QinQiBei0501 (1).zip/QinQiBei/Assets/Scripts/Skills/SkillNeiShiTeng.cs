﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillNeiShiTeng : MonoBehaviour
{
    private bool isChange = false;
    private int flag = 0;
    private float xTemp;
    private Vector3 posTemp;
    private float a = 1f;
    private SpriteRenderer srSelf;
    private SpriteRenderer srFarestEnemy;

    private void Start()
    {
        srSelf = this.GetComponent<SpriteRenderer>();
        xTemp = Global.Enemy.transform.GetChild(flag).position.x;
        for (int i = flag + 1; i < Global.Enemy.transform.childCount; i++)
        {
            if (Global.Enemy.transform.GetChild(i).position.x > xTemp)
            {
                xTemp = Global.Enemy.transform.GetChild(i).position.x;
                flag = i;
            }
        }
        this.gameObject.GetComponent<FigureMove>().GetMultiple(0, 2f);
        Global.Enemy.transform.GetChild(flag).gameObject.GetComponent<FigureMove>().GetMultiple(0, 2f);
        srFarestEnemy = Global.Enemy.transform.GetChild(flag).gameObject.GetComponent<SpriteRenderer>();
        posTemp = this.transform.position;
        InvokeRepeating("ChangePosition", 0f, 0.2f);
    }

    private void ChangePosition()
    {
        if (!isChange)
        {
            a -= 0.2f;
            srSelf.color = new Color(255, 255, 255, a);
            srFarestEnemy.color = new Color(255, 255, 255, a);
            if (a <= 0)
            {
                this.transform.position = Global.Enemy.transform.GetChild(flag).position;
                Global.Enemy.transform.GetChild(flag).position = posTemp;
                isChange = true;
            }
        }
        else
        {
            a += 0.2f;
            if (a > 1f)
                a = 1f;
            srSelf.color = new Color(255, 255, 255, a);
            srFarestEnemy.color = new Color(255, 255, 255, a);
            if (a == 1f)
                CancelInvoke();
        }
    }
}