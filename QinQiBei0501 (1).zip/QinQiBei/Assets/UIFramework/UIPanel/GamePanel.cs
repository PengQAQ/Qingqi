﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GamePanel : BasePanel {

	public static Transform[] imgArray;
    private static int arrayNum = 3;
    public static GameObject[] objArray;   //人物数组 
    private static int num = 3;				//人物数目
    /// <summary>
    /// 重写进入函数
    /// </summary>
    public override void OnEnter()
    {
        base.OnEnter();

        Global.GameManager.GetComponent<GameManager>().Players.SetActive(true);
        Global.GameManager.GetComponent<GameManager>().Enemys.SetActive(true);
        Global.GameManager.GetComponent<GameManager>().BF.SetActive(true);
        Global.GameManager.GetComponent<GameManager>().Ctrl.SetActive(true);

        GetimgArray();
        GetObjArray();
    }

    public override void OnExit()
    {
        //base.OnExit();
        CanvasGroup canvasGroup = GetComponent<CanvasGroup>();
        canvasGroup.alpha = 1;
        canvasGroup.blocksRaycasts = false;

    }
    /// <summary>
    /// 得到道具数组
    /// </summary>
    void GetimgArray()
    {
        imgArray = new Transform[arrayNum];
		GameObject parent = GameObject.Find("IsCanCarry").gameObject;
        int i = 0;
		foreach(Transform img in parent.transform)
        {
            imgArray[i] = img;
            i++;
			Debug.Log(img.name);
        }
    }

    static void GetObjArray()
    {
        objArray = new GameObject[num];
        //GameObject grandPa = GameObject.Find("AllObject");
        GameObject parent = GameObject.Find("Player");
        int i = 0;
        foreach (Transform child in parent.transform)
        {
            GameObject ob = GameObject.Find(child.name);
            objArray[i] = ob;
            i++;
            Debug.Log(child.name);
        }
    }
}
