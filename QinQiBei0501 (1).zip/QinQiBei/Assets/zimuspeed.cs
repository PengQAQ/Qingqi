﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zimuspeed : MonoBehaviour {

    public float speed;
	// Use this for initialization
	void Start () {
        speed = 0.2f;
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 nextPos = new Vector3(gameObject.transform.position.x , gameObject.transform.position.y + speed, gameObject.transform.position.z);
        this.gameObject.transform.position = nextPos;
    }
}
